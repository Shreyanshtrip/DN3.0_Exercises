package com.tester;


import com.product.Product;
import com.searching.SearchingAlog;

public class Tester {
	public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "phone", "Electronics"),
            new Product("3", "Headphones", "Accessories"),
            new Product("4", "Keyboard", "Accessories"),
            new Product("5", "Mouse", "Accessories")
        };
        Product result = SearchingAlog.linearSearch(products, "phone");
        if (result != null) {
            System.out.println("Linear Search Found: " + result.getProductName());
        } else {
            System.out.println("Linear Search: Product not found");
        }
        SearchingAlog.sortProductsByName(products);
        result = SearchingAlog.binarySearch(products, "phone");
        if (result != null) {
            System.out.println("Binary Search Found: " + result.getProductName());
        } else {
            System.out.println("Binary Search: Product not found");
        }
    }
}