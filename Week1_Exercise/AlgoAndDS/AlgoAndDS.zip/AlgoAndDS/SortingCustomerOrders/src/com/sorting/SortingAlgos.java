package com.sorting;

import com.order.Order;

public class SortingAlgos {
    public static void bubbleSort(Order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }
    
    public static void insertionSort(Order[] orders) {
        int n = orders.length;
        for (int i = 1; i < n; ++i) {
            Order key = orders[i];
            int j = i - 1;
            while (j >= 0 && orders[j].getTotalPrice() > key.getTotalPrice()) {
                orders[j + 1] = orders[j];
                j = j - 1;
            }
            orders[j + 1] = key;
        }
    }
    public static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);
            quickSort(orders, pi + 1, high);
        }
    }

    private static int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].getTotalPrice();
        int i = (low - 1);

        for (int j = low; j < high; j++) {
            if (orders[j].getTotalPrice() <= pivot) {
                i++;
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;

        return i + 1;
    }
    
    
    
 // Merge Sort
    public static void mergeSort(Order[] orders, int left, int right) {
        if (left < right) {
            int middle = (left + right) / 2;
            mergeSort(orders, left, middle);
            mergeSort(orders, middle + 1, right);
            merge(orders, left, middle, right);
        }
    }

    private static void merge(Order[] orders, int left, int middle, int right) {
        int n1 = middle - left + 1;
        int n2 = right - middle;
        Order[] leftArray = new Order[n1];
        Order[] rightArray = new Order[n2];
        for (int i = 0; i < n1; ++i) {
            leftArray[i] = orders[left + i];
        }
        for (int j = 0; j < n2; ++j) {
            rightArray[j] = orders[middle + 1 + j];
        }
        int i = 0, j = 0;
        int k = left;
        while (i < n1 && j < n2) {
            if (leftArray[i].getTotalPrice() <= rightArray[j].getTotalPrice()) {
                orders[k] = leftArray[i];
                i++;
            } else {
                orders[k] = rightArray[j];
                j++;
            }
            k++;
        }
        while (i < n1) {
            orders[k] = leftArray[i];
            i++;
            k++;
        }
        while (j < n2) {
            orders[k] = rightArray[j];
            j++;
            k++;
        }
    }

}
