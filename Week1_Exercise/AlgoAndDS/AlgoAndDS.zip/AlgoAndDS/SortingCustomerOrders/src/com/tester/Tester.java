package com.tester;

import com.order.Order;
import com.sorting.SortingAlgos;
public class Tester {

    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Shreyansh", 250.50),
            new Order("2", "Raj", 100.00),
            new Order("3", "Rahul", 300.00),
            new Order("4", "Manish", 150.75),
            new Order("5", "Priyanshu", 200.00)
        };
        System.out.println("Bubble Sort:");
        SortingAlgos.bubbleSort(orders);
        for (Order order : orders) {
            System.out.println(order.getOrderId() + ": " + order.getTotalPrice());
        }
        orders = new Order[] {
        		  new Order("1", "Shreyansh", 250.50),
                  new Order("2", "Raj", 100.00),
                  new Order("3", "Rahul", 300.00),
                  new Order("4", "Manish", 150.75),
                  new Order("5", "Priyanshu", 200.00)
        };
        System.out.println("Insertion Sort:");
        SortingAlgos.insertionSort(orders);
        for (Order order : orders) {
            System.out.println(order.getOrderId() + ": " + order.getTotalPrice());
        }
        orders = new Order[] {
        		  new Order("1", "Shreyansh", 250.50),
                  new Order("2", "Raj", 100.00),
                  new Order("3", "Rahul", 300.00),
                  new Order("4", "Manish", 150.75),
                  new Order("5", "Priyanshu", 200.00)
        };
        System.out.println("Quick Sort:");
        SortingAlgos.quickSort(orders, 0, orders.length - 1);
        for (Order order : orders) {
            System.out.println(order.getOrderId() + ": " + order.getTotalPrice());
        }

        orders = new Order[] {
        		  new Order("1", "Shreyansh", 250.50),
                  new Order("2", "Raj", 100.00),
                  new Order("3", "Rahul", 300.00),
                  new Order("4", "Manish", 150.75),
                  new Order("5", "Priyanshu", 200.00)
        };
        System.out.println("Merge Sort:");
        SortingAlgos.mergeSort(orders, 0, orders.length - 1);
        for (Order order : orders) {
            System.out.println(order.getOrderId() + ": " + order.getTotalPrice());
        }
    }
}
