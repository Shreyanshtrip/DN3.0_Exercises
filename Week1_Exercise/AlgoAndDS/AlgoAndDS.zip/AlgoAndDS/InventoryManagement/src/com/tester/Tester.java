package com.tester;

import com.product.Inventory;
import com.product.Product;

public class Tester {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        Product product1 = new Product("1", "Product 1", 10, 99.99);
        Product product2 = new Product("2", "Product 2", 20, 199.99);

        inventory.addProduct(product1);
        inventory.addProduct(product2);
        Product updatedProduct2 = new Product("2", "Updated Product 2", 30, 299.99);
        inventory.updateProduct(updatedProduct2);
        inventory.deleteProduct("1");
        Product retrievedProduct = inventory.getProduct("2");
        if (retrievedProduct != null) {
            System.out.println("Retrieved Product: " + retrievedProduct.getProductName());
        }
    }
}
