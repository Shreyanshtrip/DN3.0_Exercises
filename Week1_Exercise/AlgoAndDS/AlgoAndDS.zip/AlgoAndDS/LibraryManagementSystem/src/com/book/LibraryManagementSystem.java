package com.book;
public class LibraryManagementSystem {
    private Book[] books;
    private int size;

    // Constructor
    public LibraryManagementSystem(int capacity) {
        books = new Book[capacity];
        size = 0;
    }

    // Method to add a book
    public void addBook(Book book) {
        if (size < books.length) {
            books[size] = book;
            size++;
        } else {
            System.out.println("Library is full. Cannot add more books.");
        }
    }

    // Linear search to find a book by title
    public Book linearSearchByTitle(String title) {
        for (int i = 0; i < size; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }
    public Book binarySearchByTitle(String title) {
        int left = 0;
        int right = size - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);
            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    // Method to print all books
    public void printBooks() {
        for (int i = 0; i < size; i++) {
            System.out.println(books[i]);
        }
    }

    // Main method to demonstrate functionality
    public static void main(String[] args) {
        LibraryManagementSystem library = new LibraryManagementSystem(5);

        Book b1 = new Book(1, "1984", "Burning Delhi");
        Book b2 = new Book(2, "Wings of fire", "APJ kalam");
        Book b3 = new Book(3, "The Great Gatsby", "F. Scott Fitzgerald");

        library.addBook(b1);
        library.addBook(b2);
        library.addBook(b3);

        System.out.println("All Books:");
        library.printBooks();

        System.out.println("\nLinear Search for '1984':");
        System.out.println(library.linearSearchByTitle("1984"));

        System.out.println("\nBinary Search for 'The Great Gatsby':");
        System.out.println(library.binarySearchByTitle("The Great Gatsby"));
    }
}

