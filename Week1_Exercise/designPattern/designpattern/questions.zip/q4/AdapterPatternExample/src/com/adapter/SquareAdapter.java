package com.adapter;

import com.app.PaymentProcessor;
import com.app.SquareGateway;

public class SquareAdapter implements PaymentProcessor {
    private SquareGateway squareGateway;

    public SquareAdapter() {
        this.squareGateway = new SquareGateway();
    }

    public void processPayment(double amount) {
        squareGateway.doPayment(amount);
    }
}
