package com.adapter;

import com.app.PaymentProcessor;
import com.app.StripeGateway;

public class StripeAdapter implements PaymentProcessor {
    private StripeGateway stripeGateway;

    public StripeAdapter() {
        this.stripeGateway = new StripeGateway();
    }

    public void processPayment(double amount) {
        stripeGateway.pay(amount);
    }
}
