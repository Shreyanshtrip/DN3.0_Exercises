package com.tester;

import com.adapter.PayPalAdapter;
import com.adapter.SquareAdapter;
import com.adapter.StripeAdapter;
import com.app.PaymentProcessor;

public class TesterAdapter {
 public static void main(String[] args) {
	 
     PaymentProcessor payPalProcessor = new PayPalAdapter();
     payPalProcessor.processPayment(154.0);

     PaymentProcessor stripeProcessor = new StripeAdapter();
     stripeProcessor.processPayment(567.0);

     PaymentProcessor squareProcessor = new SquareAdapter();
     squareProcessor.processPayment(320.0);
 }
}
