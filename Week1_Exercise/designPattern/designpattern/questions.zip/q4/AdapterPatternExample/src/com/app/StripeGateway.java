package com.app;

public class StripeGateway {
    public void pay(double amount) {
        System.out.println("Payment of $" + amount + " made through Stripe.");
    }
}