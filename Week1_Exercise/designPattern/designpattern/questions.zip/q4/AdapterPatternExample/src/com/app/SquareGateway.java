package com.app;

public class SquareGateway {
    public void doPayment(double amount) {
        System.out.println("Payment of $" + amount + " made through Square.");
    }
}
