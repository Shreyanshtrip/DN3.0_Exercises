package com.app;


public interface PaymentProcessor {
 void processPayment(double amount);
}

