package com.tester;

import com.app.CreditCardPayment;
import com.app.PayPalPayment;
import com.app.PaymentContext;
import com.app.PaymentStrategy;

public class Tester {
 public static void main(String[] args) {
     PaymentContext context = new PaymentContext();
     PaymentStrategy creditCardPayment = new CreditCardPayment("1234567890123456", "John Doe", "123", "12/25");
     context.setPaymentStrategy(creditCardPayment);
     context.pay(10000.00);

     System.out.println();
     PaymentStrategy payPalPayment = new PayPalPayment("john.doe@example.com", "password123");
     context.setPaymentStrategy(payPalPayment);
     context.pay(2000.00);
 }
}
