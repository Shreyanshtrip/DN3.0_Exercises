package com.app;

public interface PaymentStrategy {
    void pay(double amount);
}