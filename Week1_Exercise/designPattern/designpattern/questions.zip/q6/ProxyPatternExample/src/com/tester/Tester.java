package com.tester;

import com.app.Image;
import com.app.ProxyImage;

public class Tester {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("Image1.jpg");
        Image image2 = new ProxyImage("Image2.jpg");
        image1.display();
        System.out.println("");
        image1.display();
        System.out.println("");
        image2.display();
        System.out.println("");
        image2.display();
    }
}
