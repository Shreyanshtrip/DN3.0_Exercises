package com.app;

public interface Image {
 void display();
}

