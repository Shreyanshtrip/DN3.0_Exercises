package com.tester;

import com.app.Student;
import com.app.StudentController;
import com.app.StudentView;

public class Tester {

 public static void main(String[] args) {
     Student student = new Student("Shreyansh Triathi", "120809", "A");
     StudentView view = new StudentView();
     StudentController controller = new StudentController(student, view);
     controller.updateView();
     System.out.println();
     controller.setStudentName("Shreyansh Tripathi");
     controller.setStudentId("170124");
     controller.setStudentGrade("B");
     controller.updateView();
 }
}
