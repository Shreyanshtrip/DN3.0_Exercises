package com.tester;

import com.computer.Computer;

public class TestBuilderPattern {
 public static void main(String[] args) {
     
     Computer basicComputer = new Computer.Builder("Intel i5", "8GB").build();
     System.out.println("Basic Computer: ");
     System.out.println("CPU: " + basicComputer.getCPU());
     System.out.println("RAM: " + basicComputer.getRAM());

     Computer highEndComputer = new Computer.Builder("Intel i5", "32GB")
             .setStorage("1TB SSD")
             .build();
     System.out.println("\nHigh End Computer: ");
     System.out.println("CPU: " + highEndComputer.getCPU());
     System.out.println("RAM: " + highEndComputer.getRAM());
     System.out.println("Storage: " + highEndComputer.getStorage());
     
 }
}
