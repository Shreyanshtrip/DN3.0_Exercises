package com.logger;

public class Logger {
    // Logger has Private static instance of itself
    private static Logger instance;

    // private logger constructor is initialised
    private Logger() {
        
    }

    // Public static method to provide access to the instance
    public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }

    // Method to log data
    public void log(String message) {
        System.out.println(message);
    }
}
