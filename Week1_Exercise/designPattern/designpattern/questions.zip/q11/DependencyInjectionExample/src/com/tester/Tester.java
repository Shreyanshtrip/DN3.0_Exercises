package com.tester;

import com.app.CustomerRepository;
import com.app.CustomerRepositoryImpl;
import com.app.CustomerService;

public class Tester {

	public static void main(String[] args) {
        CustomerRepository customerRepository = new CustomerRepositoryImpl();
        CustomerService customerService = new CustomerService(customerRepository);
        String customerDetails = customerService.getCustomerDetails("120817");
        System.out.println(customerDetails);
    }
}
