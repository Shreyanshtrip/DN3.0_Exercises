package com.tester;
import com.app.MobileApp;
import com.app.Observer;
import com.app.StockMarket;
import com.app.WebApp;

public class Tester {
 public static void main(String[] args) {
     StockMarket stockMarket = new StockMarket();

     Observer mobileApp = new MobileApp("MobileApp");
     Observer webApp = new WebApp("WebApp");

     stockMarket.registerObserver(mobileApp);
     stockMarket.registerObserver(webApp);
     stockMarket.setPrice(200.00);
     System.out.println();

     stockMarket.setPrice(128.50);
     System.out.println();

     stockMarket.removeObserver(mobileApp);
     stockMarket.setPrice(340.75);
 }
}
