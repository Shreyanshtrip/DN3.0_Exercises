package com.app;

public interface Observer {
    void update(double price);
}
