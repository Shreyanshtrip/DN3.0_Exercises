package com.tester;

import com.app.EmailNotifier;
import com.app.Notifier;
import com.app.SMSNotifierDecorator;
import com.app.SlackNotifierDecorator;

public class Tester {
 public static void main(String[] args) {
     Notifier emailNotifier = new EmailNotifier();
     Notifier emailAndSMSNotifier = new SMSNotifierDecorator(emailNotifier);
     Notifier emailSMSAndSlackNotifier = new SlackNotifierDecorator(emailAndSMSNotifier);
     emailSMSAndSlackNotifier.send("Hey there, this is a multi-channel notification!");
 }
}
