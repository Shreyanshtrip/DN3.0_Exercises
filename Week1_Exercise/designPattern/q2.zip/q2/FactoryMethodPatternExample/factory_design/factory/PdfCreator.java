package factory;

import factory.Interfaces.IDocument;

public class PdfCreator extends DocumentFactory {
    protected IDocument CreateDocument() {
        //This should create return PdfDocument
        System.out.println("Creating Pdf Document");
        return new PdfDocument();
    }
}
