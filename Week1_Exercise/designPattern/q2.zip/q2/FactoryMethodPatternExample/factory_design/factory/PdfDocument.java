package factory;

import factory.Interfaces.IDocument;

public class PdfDocument implements IDocument {
    @Override
    public String getFormat()
    {
        return "pdf document";
    }
}