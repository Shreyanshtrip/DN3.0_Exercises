package factory;

import factory.Interfaces.IDocument;

public class ExcelCreator extends DocumentFactory {
    @Override
    protected IDocument CreateDocument()
    {
        System.out.println("Creating Excel Document");
        return new ExcelDocument();
    }
}
