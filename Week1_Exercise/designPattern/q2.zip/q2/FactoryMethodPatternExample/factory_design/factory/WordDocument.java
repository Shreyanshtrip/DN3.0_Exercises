package factory;

import factory.Interfaces.IDocument;
import factory.Interfaces.IWordDocument;

public class WordDocument implements IWordDocument {
    @Override
    public String getFormat() {
        return "Word document";
    }
}
