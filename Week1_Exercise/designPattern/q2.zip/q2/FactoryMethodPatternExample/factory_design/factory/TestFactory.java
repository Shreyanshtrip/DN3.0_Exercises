package factory;

import factory.Interfaces.IDocument;

public class TestFactory {
    public void TestOperation()
    {
        DocumentFactory factory = new PdfCreator();
        //As a client I don't care about how the object is created
        //I am letting the subclass decide which class to instantiate
        IDocument document = factory.SaveDocument();
        System.out.println("Format: " +document.getFormat());
        System.out.println();

        DocumentFactory wordFactory = new WordCreator();
        IDocument wordDocument = wordFactory.SaveDocument();
        System.out.println("Format: " +wordDocument.getFormat());
        System.out.println();

        DocumentFactory excelFactory = new ExcelCreator();
        IDocument excelDocument = excelFactory.SaveDocument();
        System.out.println("Format: " +excelDocument.getFormat());
        System.out.println();
    }
}
