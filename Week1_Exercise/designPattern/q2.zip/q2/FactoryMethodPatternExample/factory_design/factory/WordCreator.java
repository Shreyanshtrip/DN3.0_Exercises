package factory;

import factory.Interfaces.IDocument;

public class WordCreator extends  DocumentFactory{
    @Override
    protected IDocument CreateDocument() {
        System.out.println("Creating Word Document");
        return new WordDocument();
    }
}
