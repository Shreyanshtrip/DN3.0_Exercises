package factory.Interfaces;

public interface IExcelDocument {
    //Actually not needed .According to book Head First Design Pattern .
    //Implementing  only for Word document
}
