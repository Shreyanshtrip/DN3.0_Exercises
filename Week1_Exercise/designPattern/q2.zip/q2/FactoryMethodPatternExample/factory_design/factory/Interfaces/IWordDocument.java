package factory.Interfaces;

public interface IWordDocument extends  IDocument{
    //Actually not needed .According to book Head First Design Pattern .
    //Still will use Since it is told in question.
}
