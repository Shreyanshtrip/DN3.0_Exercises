package factory.Interfaces;

public interface IDocument {
    public String getFormat();
}
