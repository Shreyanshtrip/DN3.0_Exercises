package factory.Interfaces;

public interface IPdfDocument extends  IDocument{
    //Actually not needed .According to book Head First Design Pattern .
    //Implementing  only for Word document
}
