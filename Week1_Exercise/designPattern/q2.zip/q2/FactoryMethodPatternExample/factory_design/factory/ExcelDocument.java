package factory;

import factory.Interfaces.IDocument;

public class ExcelDocument implements IDocument {
    public String getFormat()
    {
        return "excel document";
    }
}
