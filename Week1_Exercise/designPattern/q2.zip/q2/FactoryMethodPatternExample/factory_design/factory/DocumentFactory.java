package factory;

import factory.Interfaces.IDocument;

public abstract class DocumentFactory {
    public DocumentFactory() { }

    public IDocument SaveDocument()
    {
        IDocument document = CreateDocument();
        System.out.println("Created " + document.getFormat());
        System.out.println("Saved " +document.getFormat() );
        return document;
    }

    //This is our factory Method.
    protected abstract IDocument CreateDocument();
}
