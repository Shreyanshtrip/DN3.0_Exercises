import factory.TestFactory;

public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");
        TestFactory factory = new TestFactory();
        factory.TestOperation();
    }
}