package com.code.api.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginDTO {
	
	    private String email;
	    
	    private String password;

		public Object getEmail() {
			// TODO Auto-generated method stub
			return null;
		}

		public Object getPassword() {
			// TODO Auto-generated method stub
			return null;
		}
	    
	    // getters and setters here...
	}

