package com.library.repository;

//@Repository
public class BookRepository {

	public void addBook() {
		System.out.println("Book added");
	}
}
