package com.library.repository;

public class BookRepository {

	public void addBook() {
		System.out.println("Book added");
	}
}
